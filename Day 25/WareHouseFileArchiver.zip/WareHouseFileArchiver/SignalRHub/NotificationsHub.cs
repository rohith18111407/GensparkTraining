using Microsoft.AspNetCore.SignalR;

namespace WareHouseFileArchiver.SignalRHub
{
    public class NotificationsHub : Hub
    {
        
    }
}